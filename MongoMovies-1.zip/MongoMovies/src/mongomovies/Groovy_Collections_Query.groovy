package mongomovies

import groovy.json.JsonOutput
import groovy.json.JsonSlurper




/*
 *  Obtaining data
 */

// Path to local json file containing our dataset
def jsonFilePath = '/resources/movies.json'


// Load movie list from JSON file
def jsonSlurper = new JsonSlurper()
def file = new File(jsonFilePath)
List<Map> movieList = jsonSlurper.parseText(file.text)




/*
 * Processing data 
 */


// Data selection (pick movies released in 1990 or earlier)
def classicMovies = movieList.findAll { it.year <= 1990  }


// Data projection (extract relevant fields)
def projectedMovies = classicMovies.collect { 
	[
		title: it.title,
		cast: it.cast,
		genres: it.genres
	]
}


// Data filtering (remove movies with unspecified genres)
def moviesWithGenres = projectedMovies.findAll { !it.genres.empty }


// Data grouping (group classic movies by genres)
def moviesByGenres = [:]

for(movie in moviesWithGenres) {
	for(genre in movie.genres) {
		if(!moviesByGenres.containsKey(genre) ) {
			moviesByGenres[genre] = new ArrayList()
		}
		moviesByGenres[genre] << movie
	}
}




/*
 * Result Feedback 
 */

// Show Obtained data
def data = JsonOutput.toJson(moviesByGenres)
println(JsonOutput.prettyPrint(data))


// Show Report
for(entry in moviesByGenres) {
	println("${entry.key}:")
	for(movie in entry.value) {
		println("\t${it.title}");
		println("\t\tcast: ${it.cast}")
		println()
	}	
	println()
}
