package mongomovies

import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.bson.Document

import com.mongodb.client.MongoClients

import static com.mongodb.client.model.Filters.*
import static com.mongodb.client.model.Projections.*
import static com.mongodb.client.model.Sorts.*
import static com.mongodb.client.model.Accumulators.*
import static com.mongodb.client.model.Aggregates.*



/*
 * Loading resources 
 */


// Path to mongo atlas credentials
def credFilePath = '/resources/mongodb.properties'
// Path to local json file containing our dataset
def jsonFilePath = '/resources/movies.json'


// Load credentials for Mongo ATLAS from /resources/mongodb.properties
// the format of the file should be
//		USN=yourUsername
//		PWD=yourPassword
//		DATABASE=yourDatabaseName
def propertiesFile = new File(credFilePath)
def properties = new Properties()
// Add credentials from mongo atlas credential file as properties
propertiesFile.withInputStream {
	properties.load(it)
}




/*
 *  Sending data to Mongo atlas
 */


// Load movie list from JSON file
def jsonSlurper = new JsonSlurper()
def file = new File(jsonFilePath)
List<Map> movieList = jsonSlurper.parseText(file.text)


// create connection with mongo atlas
def mongoClient = MongoClients.create("mongodb+srv://${properties.USN}:${properties.PWD}@${properties.CLUSTER}.${properties.HOST}.mongodb.net/${properties.DB}?retryWrites=true&w=majority");
def db = mongoClient.getDatabase(properties.DB);

// select to work with movies collection from mongo atlas
def movieCollection = db.getCollection("movies")

// clear any data in movies collection
movieCollection.drop()

// upload movieList to mongo atlas movie collection
for (map in movieList) {
	def json = JsonOutput.toJson(obj)
	def doc = Document.parse(json)
	col.insertOne(doc)
}




/*
 *	Mongo queries to retrieve data from mongo atlas 
 */

def resultList = col.aggregate([
	match(lte('year',1990)),
	project(fields(include('title', 'cast', 'genres'),excludeId())),
	unwind('$genres'),
	group('$genres'),
])




/*
 * Result Feedback
 */

println()
println()
resultList.each { println(it) }
println()
println()


